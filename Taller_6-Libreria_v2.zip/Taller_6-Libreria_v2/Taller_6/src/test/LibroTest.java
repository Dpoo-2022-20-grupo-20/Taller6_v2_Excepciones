package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import modelo.Categoria;
import modelo.Imagen;
import modelo.Libro;


public class LibroTest 
{

    /**
     * Atributo usado para las pruebas
     */
    private static Libro libro;

    private static Categoria categoria = new Categoria("Categoria", true);

    private static Imagen imagen = new Imagen("test",10,10);

    @BeforeAll
    public static void setUp()
    {
        libro = new Libro("titulo","autor",3.5,categoria);
    }

    @AfterAll
    public static void tearDown()
    {
        Categoria categoria = new Categoria("Categoria", true);
        libro = new Libro("titulo","autor",3.5,categoria);
    }

    @Test
    public void testDarTitulo()
    {
        assertEquals("titulo",libro.darTitulo());
    }

    @Test
    public void testDarAutor()
    {
        assertEquals("autor",libro.darAutor());
    }

    @Test
    public void testDarCalificacion()
    {
        assertEquals(3.5,libro.darCalificacion());
    }

    @Test
    public void testDarCategoria()
    {
        assertEquals(categoria,libro.darCategoria());
    }

    @Test
    public void testDarPortada()
    {
        assertEquals(imagen,libro.darPortada());
    }

    @Test
    public void testCambiarPortada()
    {
        libro.cambiarPortada(imagen);
        assertEquals(libro.darPortada(), imagen);
    }

    @Test
    public void testTienePortada()
    {
        assertNotNull(libro.tienePortada());
    }
}
