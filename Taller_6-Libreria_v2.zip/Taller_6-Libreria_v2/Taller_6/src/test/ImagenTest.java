package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import modelo.Imagen;

public class ImagenTest {
	
	private static Imagen imagen;

	@BeforeEach
	void setUp() throws Exception {
		imagen = new Imagen("test",10,10);
	}

	@AfterEach
	void tearDown() throws Exception {
		imagen = new Imagen("test",10,10);
	}


	@Test
	void testDarRutaArchivo() {
		assertEquals("test",imagen.darRutaArchivo());
	}

	@Test
	void testDarAncho() {
		assertEquals(10,imagen.darAncho());
	}

	@Test
	void testDarAlto() {
		assertEquals(10,imagen.darAlto());
	}

}
